package empsystem.demo.query;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    @Query(name = "Employee.findByName")
    List<Employee> findEmployeesByName(@Param("name") String name);

    @Query(name = "Employee.findByDepartmentId")
    List<Employee> findEmployeesByDepartmentId(@Param("departmentId") Long departmentId);

    @Query(name = "Employee.findByEmail")
    Employee findEmployeeByEmail(@Param("email") String email);
}


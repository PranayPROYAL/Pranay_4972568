package empsystem.demo.sorting;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import empsystem.demo.model.Employee;

public class EmployeeService {

    public Page<Employee> getEmployees(Pageable pageable) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getEmployees'");
    }

    

}

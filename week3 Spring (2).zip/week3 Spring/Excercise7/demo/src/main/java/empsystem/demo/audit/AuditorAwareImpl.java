package empsystem.demo.audit;


import java.util.Optional;

import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;

@Component
public class AuditorAwareImpl implements AuditorAware<String> {

    @Override
    public Optional<String> getCurrentAuditor() {
        // Return the username of the currently authenticated user
        // For now, returning a fixed username for demonstration
        return Optional.of("admin"); // Replace with actual user context
    }
}

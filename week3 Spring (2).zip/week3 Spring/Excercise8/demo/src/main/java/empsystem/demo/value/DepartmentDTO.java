package empsystem.demo.value;


public class DepartmentDTO {

    private String name;
    private int employeeCount;

    public DepartmentDTO(String name, int employeeCount) {
        this.name = name;
        this.employeeCount = employeeCount;
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getEmployeeCount() {
        return employeeCount;
    }

    public void setEmployeeCount(int employeeCount) {
        this.employeeCount = employeeCount;
    }
}


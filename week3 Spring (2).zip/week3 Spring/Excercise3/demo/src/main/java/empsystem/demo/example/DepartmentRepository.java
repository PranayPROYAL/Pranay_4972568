package empsystem.demo.example;


import org.springframework.data.jpa.repository.JpaRepository;

import empsystem.demo.model.Department;

public interface DepartmentRepository extends JpaRepository<Department, Long> {

    // Derived query method to find departments by name
    Department findByName(String name);

    // Derived query method to find departments with more than a given number of employees
    // This requires a custom query or additional method logic if needed
    // You may need to write a custom JPQL query or use @Query annotation for complex queries
}

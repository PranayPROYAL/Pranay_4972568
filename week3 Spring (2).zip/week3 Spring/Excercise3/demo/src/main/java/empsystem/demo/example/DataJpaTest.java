package empsystem.demo.example;

public @interface DataJpaTest {

}

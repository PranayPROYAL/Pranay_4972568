package empsystem.demo.example;

public @interface Test {

}

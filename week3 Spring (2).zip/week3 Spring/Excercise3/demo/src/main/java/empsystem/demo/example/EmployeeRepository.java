package empsystem.demo.example;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import empsystem.demo.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Derived query method to find employees by name
    List<Employee> findByName(String name);

    // Derived query method to find employees by department
    List<Employee> findByDepartmentId(Long departmentId);

    // Derived query method to find employees by email
    Employee findByEmail(String email);
}

